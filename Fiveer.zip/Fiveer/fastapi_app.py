from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
from model import FiveerModel

app = FastAPI(title="Fiverr Earnings Prediction API")
model = FiveerModel()

class PredictionRequest(BaseModel):
    skill_proficiency: float
    client_satisfaction_index: float
    number_of_clients: int

class PredictionResponse(BaseModel):
    prediction: float

@app.post("/predict", response_model=PredictionResponse)
async def predict_earnings(request: PredictionRequest):
    try:
        # Validate input ranges
        if not (1.0 <= request.skill_proficiency <= 10.0):
            raise HTTPException(status_code=400, detail="Skill proficiency must be between 1.0 and 10.0")
        
        if not (1.0 <= request.client_satisfaction_index <= 10.0):
            raise HTTPException(status_code=400, detail="Client satisfaction index must be between 1.0 and 10.0")
        
        if request.number_of_clients < 0:
            raise HTTPException(status_code=400, detail="Number of clients must be non-negative")

        # Make prediction
        prediction = model.predict(
            request.skill_proficiency,
            request.client_satisfaction_index,
            request.number_of_clients
        )
        
        return PredictionResponse(prediction=prediction)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
async def root():
    return {
        "message": "Welcome to Fiverr Earnings Prediction API",
        "documentation": "https://localhost:8000/docs"
    }
