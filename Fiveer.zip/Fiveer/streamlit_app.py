import streamlit as st
from model import FiveerModel

# Initialize model
model = FiveerModel()

# Set page config
st.set_page_config(
    page_title="Fiverr Earnings Predictor",
    page_icon="💰",
    layout="centered"
)

# Create title and description
st.title("Fiverr Earnings Predictor")
st.write("Predict your potential earnings on Fiverr based on your skills and client satisfaction.")

# Create input form
with st.form("prediction_form"):
    st.subheader("Enter your details")
    
    # Skill proficiency slider
    skill_proficiency = st.slider(
        "Skill Proficiency (1-10)",
        min_value=1.0,
        max_value=10.0,
        value=5.0,
        step=0.1
    )
    
    # Client satisfaction index slider
    client_satisfaction_index = st.slider(
        "Client Satisfaction Index (1-10)",
        min_value=1.0,
        max_value=10.0,
        value=5.0,
        step=0.1
    )
    
    # Number of clients input
    number_of_clients = st.number_input(
        "Number of Clients",
        min_value=0,
        max_value=1000,
        value=10,
        step=1
    )
    
    # Submit button
    submitted = st.form_submit_button("Predict Earnings")

# Make prediction and display result
if submitted:
    try:
        prediction = model.predict(
            skill_proficiency,
            client_satisfaction_index,
            number_of_clients
        )
        
        st.success(f"Predicted Annual Earnings: ${prediction:,.2f}")
    except Exception as e:
        st.error(f"Error making prediction: {str(e)}")
