from flask import Flask, request, jsonify
from model import FiveerModel

app = Flask(__name__)
model = FiveerModel()

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        
        # Get input parameters
        skill_proficiency = float(data.get('skill_proficiency'))
        client_satisfaction_index = float(data.get('client_satisfaction_index'))
        number_of_clients = float(data.get('number_of_clients'))
        
        # Make prediction
        prediction = model.predict(
            skill_proficiency,
            client_satisfaction_index,
            number_of_clients
        )
        
        return jsonify({
            'prediction': prediction
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
