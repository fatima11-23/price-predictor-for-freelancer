import joblib
import numpy as np

class FiveerModel:
    def __init__(self, model_path='linear_regression_model.joblib'):
        self.model = joblib.load(model_path)
        
    def predict(self, skill_proficiency, client_satisfaction_index, number_of_clients):
        """
        Predict annual earnings based on input features.
        
        Args:
            skill_proficiency: float - Skill level proficiency
            client_satisfaction_index: float - Client satisfaction score
            number_of_clients: float - Number of clients
            
        Returns:
            float: Predicted annual earnings
        """
        # Create feature array
        features = np.array([[skill_proficiency, client_satisfaction_index, number_of_clients]])
        
        # Make prediction
        prediction = self.model.predict(features)[0]
        
        return prediction
